# 🚀 Интеграции и API

## Интеграции

Yonote поддерживает множество популярных сервисов из коробки без необходимости настройки. Просто вставляйте ссылки с YouTube, Figma, Google таблиц, чтобы получить автообновляемые вставки в ваших документах. Посмотрите список доступных [интеграций](https://yonote.ru/integrations).



:::info
Большинство интеграций работает при простой вставке ссылки в документ.

:::

## API

Вы разработчик или имеете подходящие навыки? Или есть знакомый разработчик? Yonote [API](https://yonote.ru/developers) позволит получить полный контроль над вашими данными. Создавайте документы, коллекции, предоставляйте доступ пользователям программно. Все документы сохраняются в Markdown формате – попробуйте CURL запрос ниже:

```bash
curl -XPOST -H "Content-type: application/json" -d '{
  "title": "My first document",
  "text": "Hello from the API 👋",
  "collectionId": "COLLECTION_ID", // ищите id коллекции в ссылке, например https://domain.yonote.ru/collection/welcome-zWmtltQUgg
  "token": "API_TOKEN", // получите токен API здесь https://app.yonote.ru/settings/tokens
  "publish": true
}' 'https://app.yonote.ru/api/documents.create'
```


