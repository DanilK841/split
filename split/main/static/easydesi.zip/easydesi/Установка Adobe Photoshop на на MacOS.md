# Установка Adobe Photoshop на на MacOS

### 1. Скачиваем установочный файл

<https://disk.yandex.ru/d/joGgPDhtEysDGw>

### 2. Установить в терминале Rosetta

Ошибка CCXProcess или ошибка #1?..

У вас не установлена Rosetta, откройте Терминал (через Spotlight или Finder → Программы → Утилиты).

Скопируйте и вставьте команду:

/usr/sbin/softwareupdate --install-rosetta --agree-to-license

Нажмите клавишу Enter.

Дождитесь окончания процесса, выполните повторную установку Adobe Photoshop.  

### 3. Установите Photoshop по инструкции из видео

[Видеоинструкция](https://drive.google.com/file/d/1EiJXCxUv_FE8-DVbsk_tf5mZ493kAHDz/view?usp=sharing)

[https://drive.google.com/file/d/1EiJXCxUv_FE8-DVbsk_tf5mZ493kAHDz/view?usp=sharing](embed:https://drive.google.com/file/d/1EiJXCxUv_FE8-DVbsk_tf5mZ493kAHDz/view?usp=sharing "1")


